'use client';
import { useEffect, useState } from 'react';

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
      padding: '20px 40px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      background: 'rgba(5,14,31,0.85)',
      backdropFilter: 'blur(20px)',
      borderBottom: scrolled ? '1px solid rgba(30,144,255,0.15)' : '1px solid var(--border)',
      transition: 'border-color 0.3s',
    }}>
      <div style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.5rem', fontWeight: 700 }}>
        Aqua<span style={{ color: 'var(--accent)' }}>Engage</span>
      </div>
      <a href="#contato" style={{
        background: 'var(--accent)', color: 'white', border: 'none',
        padding: '10px 24px', borderRadius: 4,
        fontSize: '0.875rem', fontWeight: 500, textDecoration: 'none',
        transition: 'background 0.2s',
      }}>
        Agendar Reunião
      </a>
    </nav>
  );
}
