'use client';
import { useState } from 'react';

export default function ContactForm() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ nome: '', empresa: '', telefone: '', email: '', clientes: '' });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const inputStyle = {
    width: '100%',
    background: 'var(--navy-2)',
    border: '1px solid var(--border)',
    borderRadius: 6,
    padding: '12px 16px',
    color: 'white',
    fontFamily: 'DM Sans, sans-serif',
    fontSize: '0.9rem',
    outline: 'none',
  };

  const labelStyle = {
    display: 'block',
    fontSize: '0.8rem',
    fontWeight: 500,
    color: 'var(--text-muted)',
    marginBottom: 8,
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
  };

  if (submitted) {
    return (
      <div style={{
        background: 'rgba(30,144,255,0.1)',
        border: '1px solid rgba(30,144,255,0.3)',
        borderRadius: 8,
        padding: '40px 24px',
        textAlign: 'center',
        color: '#90C5FF',
        fontSize: '1rem',
      }}>
        <div style={{ fontSize: '2rem', marginBottom: 16 }}>✓</div>
        <strong style={{ color: 'white', display: 'block', marginBottom: 8 }}>Solicitação recebida!</strong>
        Entraremos em contato em até 24 horas úteis.
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit}>
      <div style={{ marginBottom: 20 }}>
        <label style={labelStyle}>Nome completo</label>
        <input style={inputStyle} type="text" name="nome" placeholder="Seu nome" required onChange={handleChange} />
      </div>
      <div style={{ marginBottom: 20 }}>
        <label style={labelStyle}>Empresa</label>
        <input style={inputStyle} type="text" name="empresa" placeholder="Nome da sua empresa" required onChange={handleChange} />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
        <div>
          <label style={labelStyle}>Telefone / WhatsApp</label>
          <input style={inputStyle} type="tel" name="telefone" placeholder="(11) 9 0000-0000" required onChange={handleChange} />
        </div>
        <div>
          <label style={labelStyle}>E-mail</label>
          <input style={inputStyle} type="email" name="email" placeholder="seu@email.com" required onChange={handleChange} />
        </div>
      </div>
      <div style={{ marginBottom: 24 }}>
        <label style={labelStyle}>Número de clientes ativos</label>
        <select style={{ ...inputStyle, cursor: 'pointer' }} name="clientes" required onChange={handleChange} defaultValue="">
          <option value="" disabled>Selecione</option>
          <option value="50-100">50 a 100 clientes</option>
          <option value="100-200">100 a 200 clientes</option>
          <option value="200-300">200 a 300 clientes</option>
          <option value="300+">Mais de 300 clientes</option>
        </select>
      </div>
      <button type="submit" style={{
        width: '100%',
        background: 'var(--accent)',
        color: 'white',
        border: 'none',
        padding: 16,
        borderRadius: 6,
        fontFamily: 'DM Sans, sans-serif',
        fontSize: '1rem',
        fontWeight: 600,
        cursor: 'pointer',
      }}>
        Solicitar Apresentação →
      </button>
      <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textAlign: 'center', marginTop: 16 }}>
        Seus dados são tratados com total confidencialidade.
      </p>
    </form>
  );
}
