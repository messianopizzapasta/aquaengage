import { Playfair_Display, DM_Sans } from 'next/font/google';
import './globals.css';

const playfair = Playfair_Display({ subsets: ['latin'], variable: '--font-serif', weight: ['400','600','700'] });
const dmSans = DM_Sans({ subsets: ['latin'], variable: '--font-sans', weight: ['300','400','500','600'] });

export const metadata = {
  title: 'AquaEngage – Plataforma White-Label de Customer Engagement para Piscinas Premium',
  description: 'Plataforma white-label de customer engagement para empresas premium de manutenção de piscinas em São Paulo. Aumente a fidelização de clientes e sua receita mensal.',
  keywords: 'manutenção de piscinas, fidelização de clientes, plataforma digital, aplicativo piscinas, white-label, customer engagement, São Paulo',
  openGraph: {
    title: 'AquaEngage – Plataforma White-Label de Customer Engagement',
    description: 'Sua própria plataforma digital para fidelização e crescimento de receita.',
    type: 'website',
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="pt-BR" className={`${playfair.variable} ${dmSans.variable}`}>
      <body>{children}</body>
    </html>
  );
}
