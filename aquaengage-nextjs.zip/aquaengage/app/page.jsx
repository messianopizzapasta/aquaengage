'use client';
import { useEffect } from 'react';
import Nav from '../components/Nav';
import ContactForm from '../components/ContactForm';

export default function Home() {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry, i) => {
        if (entry.isIntersecting) {
          setTimeout(() => entry.target.classList.add('visible'), i * 80);
        }
      });
    }, { threshold: 0.1 });
    document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <Nav />

      {/* HERO */}
      <section style={{
        minHeight: '100vh', display: 'flex', alignItems: 'center',
        padding: '120px 40px 80px', position: 'relative', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'radial-gradient(ellipse 80% 60% at 60% 50%, rgba(10,75,140,0.35) 0%, transparent 65%), radial-gradient(ellipse 50% 40% at 85% 20%, rgba(30,144,255,0.12) 0%, transparent 60%), var(--navy)',
        }} />
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: 'linear-gradient(rgba(30,144,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(30,144,255,0.04) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
          maskImage: 'radial-gradient(ellipse 80% 80% at center, black, transparent)',
        }} />
        <div style={{ maxWidth: 1200, margin: '0 auto', width: '100%', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80, alignItems: 'center', position: 'relative', zIndex: 2 }}>
          <div>
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 8,
              background: 'rgba(201,169,110,0.12)', border: '1px solid rgba(201,169,110,0.3)',
              borderRadius: 100, padding: '6px 16px', fontSize: '0.75rem', fontWeight: 600,
              color: 'var(--gold-light)', letterSpacing: '0.08em', textTransform: 'uppercase',
              marginBottom: 28,
            }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--gold)', display: 'inline-block' }} className="animate-pulse-dot" />
              Plataforma White-Label · São Paulo
            </div>
            <h1 style={{
              fontFamily: 'Playfair Display, serif', fontSize: 'clamp(2.5rem, 4.5vw, 3.8rem)',
              fontWeight: 700, lineHeight: 1.15, letterSpacing: '-0.02em', marginBottom: 24,
            }}>
              Sua própria plataforma digital para{' '}
              <em style={{ fontStyle: 'italic', color: 'var(--accent)' }}>fidelização</em>{' '}
              e crescimento de receita
            </h1>
            <p style={{ fontSize: '1.125rem', color: 'var(--text-muted)', lineHeight: 1.7, marginBottom: 40, fontWeight: 300 }}>
              Empresas premium de manutenção de piscinas com um aplicativo próprio — Android e iOS — para engajar clientes, automatizar comunicação e ampliar receita mensal de forma consistente.
            </p>
            <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
              <a href="#contato" style={{
                background: 'var(--accent)', color: 'white', border: 'none',
                padding: '16px 32px', borderRadius: 4,
                fontSize: '0.9375rem', fontWeight: 600, textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 8,
              }}>Agendar Reunião Estratégica →</a>
              <a href="#contato" style={{
                background: 'transparent', color: 'white',
                border: '1px solid rgba(255,255,255,0.25)',
                padding: '16px 32px', borderRadius: 4,
                fontSize: '0.9375rem', fontWeight: 500, textDecoration: 'none',
              }}>Solicitar Apresentação</a>
            </div>
          </div>
          <div style={{ position: 'relative' }}>
            <div style={{
              position: 'absolute', top: -16, right: 24,
              background: 'linear-gradient(135deg, #0F3460, var(--navy-3))',
              border: '1px solid rgba(201,169,110,0.3)',
              borderRadius: 10, padding: '12px 16px', textAlign: 'center', zIndex: 10,
            }}>
              <strong style={{ display: 'block', fontSize: '1.5rem', fontWeight: 700, color: 'var(--gold-light)', fontFamily: 'Playfair Display, serif' }}>+R$12k</strong>
              <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>receita/mês</span>
            </div>
            <div style={{
              background: 'linear-gradient(135deg, var(--navy-3) 0%, rgba(13,34,64,0.9) 100%)',
              border: '1px solid rgba(30,144,255,0.2)', borderRadius: 16, padding: 32, position: 'relative', overflow: 'hidden',
            }}>
              <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: 'linear-gradient(90deg, transparent, var(--accent), transparent)' }} />
              <div style={{ background: 'var(--navy-2)', borderRadius: 12, padding: 20, border: '1px solid var(--border)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20, paddingBottom: 16, borderBottom: '1px solid var(--border)' }}>
                  <div style={{ width: 36, height: 36, borderRadius: 8, background: 'linear-gradient(135deg, var(--accent), var(--blue-mid))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1rem' }}>🌊</div>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: '0.875rem' }}>Piscinas Premium SP</div>
                    <div style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>Powered by AquaEngage</div>
                  </div>
                </div>
                {[
                  { icon: '📋', title: 'Última manutenção', desc: '14/02 · pH 7.2 · Cloro 2.0 · ✓ Perfeito' },
                  { icon: '📸', title: 'Histórico com fotos', desc: '8 visitas registradas este mês' },
                  { icon: '🔔', title: 'Notificação push', desc: 'Oferta exclusiva: limpeza profunda R$380' },
                ].map((item, i) => (
                  <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'center', background: 'rgba(30,144,255,0.06)', borderRadius: 8, padding: 12, border: '1px solid rgba(30,144,255,0.1)', marginBottom: 10 }}>
                    <div style={{ width: 32, height: 32, borderRadius: 6, background: 'var(--accent-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.875rem', flexShrink: 0 }}>{item.icon}</div>
                    <div>
                      <strong style={{ display: 'block', fontWeight: 500, fontSize: '0.8rem' }}>{item.title}</strong>
                      <span style={{ color: 'var(--text-muted)', fontSize: '0.72rem' }}>{item.desc}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* PROBLEMS */}
      <section id="problemas" style={{ padding: '100px 40px', background: 'var(--navy-2)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div className="fade-up">
            <div style={{ fontSize: '0.75rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--accent)', marginBottom: 16 }}>O Cenário Atual</div>
            <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 'clamp(2rem, 3.5vw, 2.75rem)', fontWeight: 700, lineHeight: 1.2, letterSpacing: '-0.02em', marginBottom: 20 }}>Os problemas que estão limitando o crescimento da sua empresa</h2>
            <div style={{ width: 48, height: 2, background: 'var(--accent)', margin: '0 0 20px' }} />
            <p style={{ fontSize: '1.0625rem', color: 'var(--text-muted)', lineHeight: 1.7, maxWidth: 600 }}>Empresas de manutenção de piscinas operam com ferramentas fragmentadas, o que compromete a experiência do cliente e deixa dinheiro na mesa todos os meses.</p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 24, marginTop: 60 }}>
            {[
              { icon: '💬', title: 'Comunicação desorganizada via WhatsApp', desc: 'Mensagens perdidas, histórico inexistente e atendimento reativo. Sem estrutura, a percepção de valor da empresa cai — e o cliente começa a comparar preço.' },
              { icon: '🔍', title: 'Ausência de diferenciação no mercado', desc: 'Quando o serviço parece igual ao do concorrente, o preço vira o único critério. Sem um canal próprio, sua marca não se destaca e a fidelização fica comprometida.' },
              { icon: '📉', title: 'Perda de oportunidades de upsell', desc: 'Clientes satisfeitos comprariam mais. Mas sem um canal de ofertas estruturado, essas oportunidades se perdem a cada visita.' },
              { icon: '🔄', title: 'Baixa retenção de clientes', desc: 'Sem engajamento contínuo, o cliente se sente esquecido entre visitas. O churn silencioso corrói a carteira sem que você perceba até ser tarde demais.' },
              { icon: '📊', title: 'Ausência de dados estratégicos', desc: 'Sem métricas de engajamento, histórico centralizado e visão da carteira, é impossível tomar decisões estratégicas com base em dados reais do negócio.' },
            ].map((p, i) => (
              <div key={i} className="fade-up" style={{ background: 'var(--navy)', border: '1px solid var(--border)', borderRadius: 12, padding: 32 }}>
                <div style={{ width: 48, height: 48, borderRadius: 10, background: 'rgba(255,70,70,0.1)', border: '1px solid rgba(255,70,70,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.25rem', marginBottom: 20 }}>{p.icon}</div>
                <h3 style={{ fontSize: '1.0625rem', fontWeight: 600, marginBottom: 12 }}>{p.title}</h3>
                <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', lineHeight: 1.65 }}>{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* REVENUE */}
      <section id="impacto" style={{ padding: '100px 40px', background: 'var(--navy-2)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80, alignItems: 'center' }}>
          <div className="fade-up">
            <div style={{ fontSize: '0.75rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--accent)', marginBottom: 16 }}>Impacto Financeiro</div>
            <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 'clamp(2rem, 3.5vw, 2.75rem)', fontWeight: 700, lineHeight: 1.2, marginBottom: 20 }}>Investimento com retorno mensurável</h2>
            <div style={{ width: 48, height: 2, background: 'var(--accent)', marginBottom: 24 }} />
            <p style={{ color: 'var(--text-muted)', lineHeight: 1.75, marginBottom: 24 }}>O AquaEngage não é um custo operacional — é um canal de geração de receita. A matemática é simples e o potencial é imediato para empresas com carteiras consolidadas.</p>
            <p style={{ color: 'var(--text-muted)', lineHeight: 1.75 }}>Empresas que estruturam um canal de upsell digital capturam entre 10% e 30% da base em serviços adicionais já nos primeiros 90 dias de operação.</p>
          </div>
          <div className="fade-up" style={{
            background: 'linear-gradient(135deg, var(--navy-3), var(--navy))',
            border: '1px solid rgba(201,169,110,0.2)',
            borderRadius: 16, padding: 40, position: 'relative', overflow: 'hidden',
          }}>
            <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: 'linear-gradient(90deg, transparent, var(--gold), transparent)' }} />
            <div style={{ fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.1em', color: 'var(--gold)', marginBottom: 32, fontWeight: 600 }}>📊 Simulação de Receita Adicional</div>
            {[
              ['Clientes na carteira', '300 clientes'],
              ['Taxa de conversão (conservadora)', '10% da base'],
              ['Clientes convertidos', '30 clientes'],
              ['Valor do serviço adicional', 'R$ 400/mês'],
            ].map(([label, value], i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 0', borderBottom: '1px solid var(--border)', fontSize: '0.9rem' }}>
                <span style={{ color: 'var(--text-muted)' }}>{label}</span>
                <strong>{value}</strong>
              </div>
            ))}
            <div style={{ marginTop: 24, padding: 24, background: 'rgba(201,169,110,0.1)', border: '1px solid rgba(201,169,110,0.3)', borderRadius: 10, textAlign: 'center' }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--gold)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>Receita adicional mensal</div>
              <div style={{ fontFamily: 'Playfair Display, serif', fontSize: '2.5rem', fontWeight: 700, color: 'var(--gold-light)' }}>R$ 12.000</div>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: 4 }}>R$ 144.000 ao ano · apenas com upsell estruturado</div>
            </div>
          </div>
        </div>
      </section>

      {/* PILOT */}
      <section id="piloto" style={{ padding: '100px 40px', background: 'linear-gradient(160deg, #040B18 0%, var(--navy-2) 50%, #040B18 100%)', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: -200, left: '50%', transform: 'translateX(-50%)', width: 600, height: 600, borderRadius: '50%', background: 'radial-gradient(circle, rgba(30,144,255,0.12), transparent 70%)', pointerEvents: 'none' }} />
        <div style={{ position: 'relative', zIndex: 2, maxWidth: 700, margin: '0 auto' }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 10, background: 'rgba(201,169,110,0.1)', border: '1px solid rgba(201,169,110,0.35)', borderRadius: 100, padding: '8px 20px', fontSize: '0.8rem', fontWeight: 600, color: 'var(--gold-light)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 32 }}>
            🔒 Seleção Exclusiva · São Paulo
          </div>
          <div style={{ fontFamily: 'Playfair Display, serif', fontSize: 'clamp(4rem, 10vw, 8rem)', fontWeight: 700, background: 'linear-gradient(135deg, var(--gold), var(--gold-light))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', lineHeight: 1, marginBottom: 8 }}>1</div>
          <div style={{ fontSize: '1.25rem', color: 'var(--text-muted)', marginBottom: 40 }}>parceiro piloto está sendo selecionado em São Paulo</div>
          <div className="fade-up">
            <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 'clamp(1.5rem, 3vw, 2rem)', fontWeight: 700, lineHeight: 1.3, marginBottom: 20 }}>Uma vaga. Uma empresa. Uma oportunidade de liderar a transformação digital do setor.</h2>
            <p style={{ color: 'var(--text-muted)', marginBottom: 40, lineHeight: 1.7 }}>Estamos abrindo condições especiais de implementação para a empresa parceira que embarcará nessa jornada conosco — incluindo suporte dedicado, onboarding acelerado e posicionamento como referência de mercado.</p>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 16, justifyContent: 'center', marginBottom: 40 }}>
            {['Condições especiais de implementação', 'Suporte estratégico dedicado', 'Onboarding acelerado', 'Co-desenvolvimento de funcionalidades', 'Posição de referência no mercado'].map((perk, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, background: 'rgba(30,144,255,0.08)', border: '1px solid rgba(30,144,255,0.2)', borderRadius: 100, padding: '10px 20px', fontSize: '0.875rem' }}>
                <span style={{ color: 'var(--accent)' }}>✓</span> {perk}
              </div>
            ))}
          </div>
          <a href="#contato" style={{ background: 'var(--accent)', color: 'white', border: 'none', padding: '18px 40px', borderRadius: 4, fontSize: '1rem', fontWeight: 600, textDecoration: 'none', display: 'inline-block' }}>
            Candidatar-se ao Programa Piloto →
          </a>
        </div>
      </section>

      {/* AUTHORITY */}
      <section id="sobre" style={{ padding: '100px 40px', background: 'var(--navy)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div className="fade-up" style={{ textAlign: 'center', maxWidth: 650, margin: '0 auto 60px' }}>
            <div style={{ fontSize: '0.75rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--accent)', marginBottom: 16 }}>Por que AquaEngage</div>
            <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 'clamp(2rem, 3.5vw, 2.75rem)', fontWeight: 700, lineHeight: 1.2, marginBottom: 20 }}>Uma plataforma desenvolvida para empresas que pensam em crescimento</h2>
            <div style={{ width: 48, height: 2, background: 'var(--accent)', margin: '0 auto 20px' }} />
            <p style={{ fontSize: '1.0625rem', color: 'var(--text-muted)', lineHeight: 1.7 }}>Não somos mais um app genérico. O AquaEngage foi construído especificamente para as dinâmicas e oportunidades do mercado de manutenção de piscinas premium.</p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 32 }}>
            {[
              { num: '100%', title: 'White-label verdadeiro', desc: 'Seu cliente vê apenas a sua marca. Nenhuma referência a terceiros. Um ativo de marca que fortalece a sua posição no mercado a cada interação.' },
              { num: 'B2B', title: 'Foco em empresas premium', desc: 'Desenvolvida para negócios com carteiras consolidadas, que buscam modernização sem perder a essência do serviço personalizado e de alto padrão.' },
              { num: '360°', title: 'Visão estratégica completa', desc: 'Do aplicativo do cliente ao portal administrativo, cada funcionalidade foi desenhada para gerar dados acionáveis e oportunidades de crescimento sustentável.' },
            ].map((card, i) => (
              <div key={i} className="fade-up" style={{ padding: '36px 28px', border: '1px solid var(--border)', borderRadius: 12, transition: 'border-color 0.3s' }}>
                <div style={{ fontFamily: 'Playfair Display, serif', fontSize: '3rem', fontWeight: 700, color: 'var(--accent)', marginBottom: 12, lineHeight: 1 }}>{card.num}</div>
                <h3 style={{ fontSize: '1.0625rem', fontWeight: 600, marginBottom: 12 }}>{card.title}</h3>
                <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', lineHeight: 1.65 }}>{card.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contato" style={{ padding: '100px 40px', background: 'var(--navy-2)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80, alignItems: 'start' }}>
          <div className="fade-up">
            <div style={{ fontSize: '0.75rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--accent)', marginBottom: 16 }}>Próximo Passo</div>
            <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 'clamp(2rem, 3.5vw, 2.75rem)', fontWeight: 700, lineHeight: 1.2, marginBottom: 20 }}>Inicie uma conversa estratégica</h2>
            <div style={{ width: 48, height: 2, background: 'var(--accent)', marginBottom: 24 }} />
            <p style={{ color: 'var(--text-muted)', lineHeight: 1.7, marginBottom: 40 }}>Preencha o formulário e um especialista do AquaEngage entrará em contato para entender o momento da sua empresa e apresentar como a plataforma pode ser estruturada para o seu negócio.</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
              {[
                { icon: '📅', title: 'Reunião estratégica', desc: 'Apresentação completa da plataforma adaptada ao perfil da sua empresa.' },
                { icon: '🎯', title: 'Diagnóstico sem custo', desc: 'Avaliamos juntos o potencial de receita adicional para a sua carteira atual.' },
                { icon: '🤝', title: 'Proposta personalizada', desc: 'Nenhuma empresa é igual. Desenvolvemos uma proposta específica para o seu contexto.' },
              ].map((pt, i) => (
                <div key={i} style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
                  <div style={{ width: 40, height: 40, borderRadius: 8, background: 'var(--accent-soft)', border: '1px solid rgba(30,144,255,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1rem', flexShrink: 0 }}>{pt.icon}</div>
                  <div>
                    <h4 style={{ fontSize: '0.9375rem', fontWeight: 600, marginBottom: 4 }}>{pt.title}</h4>
                    <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>{pt.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="fade-up" style={{ background: 'var(--navy)', border: '1px solid rgba(30,144,255,0.2)', borderRadius: 16, padding: 40, position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: 'linear-gradient(90deg, transparent, var(--accent), transparent)' }} />
            <h3 style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.5rem', marginBottom: 8 }}>Solicitar Apresentação</h3>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginBottom: 32 }}>Resposta em até 24 horas úteis.</p>
            <ContactForm />
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section style={{ padding: '120px 40px', background: 'linear-gradient(160deg, var(--navy-3) 0%, var(--navy-2) 50%, var(--navy) 100%)', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        <div style={{ maxWidth: 800, margin: '0 auto', position: 'relative', zIndex: 2 }}>
          <div style={{ fontSize: '0.75rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--accent)', marginBottom: 16 }}>Transformação Digital</div>
          <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 'clamp(2rem, 4vw, 3rem)', fontWeight: 700, lineHeight: 1.2, marginBottom: 24 }}>Transforme sua empresa em referência digital no setor de piscinas</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '1.0625rem', marginBottom: 48 }}>A diferenciação começa com uma decisão. O momento é agora.</p>
          <div style={{ display: 'flex', gap: 16, justifyContent: 'center', flexWrap: 'wrap' }}>
            <a href="#contato" style={{ background: 'var(--accent)', color: 'white', border: 'none', padding: '18px 40px', borderRadius: 4, fontSize: '1rem', fontWeight: 600, textDecoration: 'none' }}>Agendar Reunião Estratégica →</a>
            <a href="#contato" style={{ background: 'transparent', color: 'white', border: '1px solid rgba(255,255,255,0.25)', padding: '18px 40px', borderRadius: 4, fontSize: '1rem', fontWeight: 500, textDecoration: 'none' }}>Solicitar Apresentação</a>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ padding: '40px', borderTop: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 16 }}>
        <div style={{ fontFamily: 'Playfair Display, serif', fontSize: '1.25rem', fontWeight: 700 }}>
          Aqua<span style={{ color: 'var(--accent)' }}>Engage</span>
        </div>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>© 2025 AquaEngage. Plataforma white-label de customer engagement para o mercado premium de manutenção de piscinas.</p>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>São Paulo, Brasil</p>
      </footer>
    </>
  );
}
