# AquaEngage — Landing Page

Plataforma White-Label de Customer Engagement para Empresas Premium de Manutenção de Piscinas.

## Stack
- **Next.js 14** (App Router)
- **TailwindCSS**
- **Google Fonts** — Playfair Display + DM Sans

## Estrutura
```
aquaengage/
├── app/
│   ├── layout.jsx       # Metadata SEO, fontes, globals
│   ├── page.jsx         # Página principal (todas as seções)
│   └── globals.css      # CSS variables, animações
├── components/
│   ├── Nav.jsx          # Navbar fixa com blur
│   └── ContactForm.jsx  # Formulário de contato
├── next.config.js
├── tailwind.config.js
└── package.json
```

## Instalação e uso

```bash
npm install
npm run dev
```

Acesse: http://localhost:3000

## Produção

```bash
npm run build
npm start
```

## Seções
1. **Hero** — Headline + app mockup + métrica de receita
2. **Problemas** — 5 problemas do mercado
3. **Impacto Financeiro** — Calculadora de receita adicional
4. **Programa Piloto** — Seleção exclusiva
5. **Autoridade** — Posicionamento estratégico
6. **Contato** — Formulário com 5 campos
7. **CTA Final** — Conversão

## SEO
- Metadata completa (title, description, keywords, OG)
- Headings hierárquicos (H1 → H2 → H3)
- Scroll suave entre seções
- Mobile responsive
