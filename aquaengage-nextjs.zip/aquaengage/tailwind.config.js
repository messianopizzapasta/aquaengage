/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,jsx,ts,tsx}', './components/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        serif: ['Playfair Display', 'Georgia', 'serif'],
        sans: ['DM Sans', 'system-ui', 'sans-serif'],
      },
      colors: {
        navy: { DEFAULT: '#050E1F', 2: '#091729', 3: '#0D2240' },
        blue: { DEFAULT: '#0A4B8C', mid: '#1565B8', accent: '#1E90FF' },
        gold: { DEFAULT: '#C9A96E', light: '#E8C98A' },
      },
    },
  },
  plugins: [],
};
